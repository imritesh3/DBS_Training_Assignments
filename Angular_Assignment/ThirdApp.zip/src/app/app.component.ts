import { Component } from '@angular/core';
import { NewserviceService } from './newservice.service';

import { Cricketer } from './cricketer';
import {CricketService } from './cricket.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ThirdApp';
 
  today:Date;
  constructor(private newservice: NewserviceService , private cricket:CricketService){}

  getDate(){
    this.today = this.newservice.getTodaysDate();
  }

  currentTime:Date;
  getCurrentTime(){
    this.currentTime = this.newservice.getTime();
  }

  formatDate:string;
  getFormattedDate()
  {
    this.formatDate = this.newservice.getFormatDate();
  }


  num1:number;
  num2:number;
  
  sum:number;
  getSum(){
    this.sum = this.newservice.addTwoNumbers(this.num1,this.num2);
  }

  diff:number;
  getDiff(){
    this.diff = this.newservice.subTwoNumbers(this.num1,this.num2);
  }

  mul:number;
  getMul(){
    this.mul = this.newservice.mulTwoNumbers(this.num1,this.num2);
  }

  div:number;
  getDiv(){
    this.div = this.newservice.divTwoNumbers(this.num1,this.num2);
  }

  mod:number;
  getMod(){
    this.mod = this.newservice.modTwoNumbers(this.num1,this.num2);
  }


  Message:string ="This is the message from parent";

  childToParent:string;
  MessageFromChild(e){
    this.childToParent=e;
    alert("Message from child to parent is:"+this.childToParent);
  }


  cric:Cricketer =this.cricket.getCricketerDetails(0);
  cricketers : Cricketer[] = this.cricket.getCricketers();
  cid:3;
  cname:"Kohli";
  cage:30;
  cskill:"Batsman";


  cricid:number = this.cricketers[0].id;
  cricname:string = this.cricketers[1].name;
  cricage:number= this.cricketers[2].age;
  cricskill : string = this.cricketers[3].skill;


  addCricketer()
  {
    var i: number;
   var flag: boolean = true;
    for (i = 0; i < this.cricketers.length; i++) {
    if (this.cricketers[i].id === +this.cid) {
        flag = false;
    alert("CricId " + this.cid + " is already present in database.");
      }
    }
if (flag == true) {
this.cricket.addCricketer(new Cricketer(this.cid, this.cname, this.cage, this.cskill));
this.cricketers = this.cricket.getCricketers();
alert("New Cricketer added");
    }
  }


  onOptionsSelected(value: number) {
    var i: number;
    for (i = 0; i < this.cricketers.length; i++) {
    if (this.cricketers[i].id === +value) {
    break;
          }
        }
    this.cricid = this.cricketers[i].id;
    this.cricname = this.cricketers[i].name;
    this.cricage = this.cricketers[i].age;
    this.cricskill = this.cricketers[i].skill;
    
      }



      updateCricketer() {
        var i: number;
        for (i = 0; i < this.cricketers.length; i++) {
        if (this.cricketers[i].id === +this.cricid) {
        this.cricket.updateCricketer(i, new Cricketer(this.cricid, this.cricname, this.cricage, this.cricskill));
        alert("Cricketer with Id: " + this.cricid +"Updated");
        break;
              }
            }
        this.cricketers = this.cricket.getCricketers();
          }
 
          deleteCricketer() {
            var i: number;
            for (i = 0; i < this.cricketers.length; i++) {
            if (this.cricketers[i].id === +this.cricid) {
            this.cricket.deleteCricketer(i);
            alert("Cricket with Id: " + this.cricid + " deleted!!");
            break;
                  }
                }
            this.cricketers = this.cricket.getCricketers();
            this.cricid = this.cricketers[0].id;
            this.cricname = this.cricketers[0].name;
            this.cricage = this.cricketers[0].age;
            this.cricskill = this.cricketers[0].skill;
          
             
              }



}
