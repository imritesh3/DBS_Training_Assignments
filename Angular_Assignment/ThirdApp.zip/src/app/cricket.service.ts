import { Injectable } from '@angular/core';
import {Cricketer} from  './cricketer'

@Injectable({
  providedIn: 'root'
})
export class CricketService {

  

  public cricket: Cricketer[] =[
    new Cricketer(1,"Dhoni","39","WicketKeeper Batsman"),
    new Cricketer(1001,"Raina","33","All Rounder"),
       ];
    
    getCricketers()
    {
      return this.cricket.slice();
    }

    getCricketerDetails(idx:number){
      return this.cricket[idx];
    }

    addCricketer(cricketer : Cricketer){
      this.cricket.push(cricketer);
    }

    updateCricketer(idx:number , updatedCricketer:Cricketer){
      this.cricket[idx] = updatedCricketer;
    }

    deleteCricketer(idx:number){
      this.cricket.splice(idx,1);
    }

}
