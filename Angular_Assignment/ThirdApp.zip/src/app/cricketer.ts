export class Cricketer{
    id:number;
    name:string;
    age: number;
    skill:string;

    constructor(id,name,age,skill)
    {
        this.id=id;
        this.name = name;
        this.age = age;
        this.skill = skill;
    }
    
}