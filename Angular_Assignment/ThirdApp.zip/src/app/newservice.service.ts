import { DatePipe } from '@angular/common';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NewserviceService {

  constructor() { }

  getTodaysDate() : Date{
    let today = new Date();
    return today;
  }

  getTime():Date{
    
    let today = new Date();
    return today;
  }


  formatDate : string;
  getFormatDate():string{
    let today = new Date();
    var datePipe = new DatePipe('en-US');
    this.formatDate = datePipe.transform(today,'dd/MM/yyyy');
    return this.formatDate;
    

  }

  // this.num3= this.num1+this.num2;
  //return this.num3;
  
  num3:number;
  addTwoNumbers(num1:number,num2:number):number{
    
   this.num3= num1+num2;
    return this.num3;
  }

  subTwoNumbers(num1:number,num2:number):number{
    
    this.num3= num1-num2;
    return this.num3;
  }

  mulTwoNumbers(num1:number,num2:number):number{
    
    this.num3 = num1*num2;
    return this.num3;
    
  }

  divTwoNumbers(num1:number,num2:number):number{
    
    this.num3 = num1/num2;
    return this.num3;
  }

  modTwoNumbers(num1:number,num2:number):number{
    
    this.num3 = num1%num2;
    return this.num3;
  }
}
