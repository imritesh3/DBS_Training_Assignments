import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Employee } from '../employees';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
})
export class EmployeesComponent implements OnInit {
  id: number = 0;
  name: string;
  dept: string;
  designation: string;
  constructor(private route: ActivatedRoute) {
    this.route.params.subscribe((params) => {
      this.id = +params['id'];
    });
    console.log('Employee id is:' + this.id);
  }

  emp: Employee[] = [
    new Employee(1, 'Ritesh', 'ITT', 'Technical Associate'),
    new Employee(2, 'Rohit', 'IBGT', 'Manager'),
    new Employee(3, 'Chakri', 'PS', 'PS SW1'),
    new Employee(4, 'Chandu', 'SWT', 'Technical Member'),
    new Employee(5, 'Gautam', 'CBGT', 'Analyst'),
  ];

  flag: boolean = true;
  ngOnInit(): void {
    for (let i = 0; i < this.emp.length; i++) {
      if (+this.id == this.emp[i].id) {
        this.flag = false;
        this.id = this.emp[i].id;
        this.name = this.emp[i].name;
        this.dept = this.emp[i].dept;
        this.designation = this.emp[i].designation;
      }
    }
  }
}
