export class Items {
  id: number;
  name: string;
  price: string;
  photo: string;
  constructor() {}
}
