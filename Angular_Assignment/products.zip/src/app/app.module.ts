import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { ProductsComponent } from './products/products.component';
import { TrainingComponent } from './training/training.component';
import { FormsModule } from '@angular/forms';

import { RouterModule, Routes } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';
const appRoutes: Routes = [
  {
    path: 'employees',
    component: EmployeesComponent,
  },
  {
    path: 'products',
    component: ProductsComponent,
  },
  {
    path: 'training',
    component: TrainingComponent,
  },

  {
    path: 'employees/:id',
    component: EmployeesComponent,
  },
];
@NgModule({
  declarations: [
    AppComponent,
    EmployeesComponent,
    ProductsComponent,
    TrainingComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
