export class Employee {
  id: number;
  name: string;
  dept: string;
  designation: string;
  constructor(id, name, dept, designatiom) {
    this.id = id;
    this.name = name;
    this.dept = dept;
    this.designation = designatiom;
  }
}
