import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  constructor(private httpClient: HttpClient) {}

  Products: any = [];
  prodItems: any = [];
  product: string;
  Items: any = [];
  itemList: any = [];
  errorMsg: string;

  ngOnInit(): void {
    this.httpClient.get('assets/data/items.json').subscribe(
      (data) => {
        this.Items = data;
      },
      (error) => {
        console.log('OOPS! Error');
        this.errorMsg = error.message;
        alert(this.errorMsg);
      }
    );

    this.httpClient.get('assets/data/prod.json').subscribe(
      (data) => {
        this.Products = data;
        console.log(this.Products);

        for (var i = 0; i < this.Products.length; i++) {
          this.prodItems[i] = [];
          for (var j = 0; j < this.Products[i].items.length; j++) {
            console.log(this.Products[i].items[j]);
            this.prodItems[i].push(this.Items[+this.Products[i].items[j]]);
          }
        }
        console.log(this.prodItems);
      },
      (error) => {
        console.log('OOPS! Error');
        this.errorMsg = error.message;
        alert(this.errorMsg);
      }
    );
    console.log(this.Products);
  }

  flag: boolean = true;

  onOptionSelected(value: string) {
    if (value != 'select') {
      this.itemList = this.prodItems[+value - 1];
      this.flag = false;
    } else {
      this.flag = true;
    }
  }
}
