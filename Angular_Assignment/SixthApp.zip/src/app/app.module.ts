import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TheatreComponent } from './theatre/theatre.component';
import { MoviesComponent } from './movies/movies.component';
import {RouterModule, Routes} from '@angular/router';

import {HttpClientModule}  from '@angular/common/http';
import { FormsModule } from '@angular/forms';

const appRoutes : Routes = [
{path: 'home',
 component: HomeComponent
},
{path: 'theatre',
 component:TheatreComponent
},
{path: 'movies',
 component:MoviesComponent
}
];


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TheatreComponent,
    MoviesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes) ,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
