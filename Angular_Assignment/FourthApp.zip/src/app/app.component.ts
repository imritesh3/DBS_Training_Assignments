import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import {Book} from './book';

import {Movies} from './movies';
import { Trains } from './trains';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FourthApp';

Books:any = [];
book:Book;
errorMsg : string;

Movies:any = [];
movie:Movies;


Trains:any = []
train : Trains;
errorMessage: string;


constructor(private httpClient: HttpClient){}
ngOnInit(){
  this.httpClient.get("assets/data/book.json").
  subscribe(data =>
    {
      console.log(data);
      this.Books = data;
    },
    (error)=>
    {
      console.log("error has occured");
      this.errorMsg = error.message;
      alert(this.errorMsg);
    }
  ); 

  this.httpClient.get("assets/data/movies.json").
  subscribe(data =>
    {
      console.log(data);
      this.Movies = data;
    },
    (error)=>
    {
      console.log("error has occured");
      this.errorMsg = error.message;
      alert(this.errorMsg);
    }
  ); 


  this.httpClient.get("assets/data/trains.json").
subscribe(data =>
  {
    console.log(data);
    this.Trains = data;
  },
  (error)=>
  {
    console.log("error has occured");
    this.errorMessage = error.message;
    alert(this.errorMessage);
  }
); 


}

name:string;
SearchByName(){
  if(this.name !=""){
    this.Movies=this.Movies.filter(res=>{
      return res.name.toLocaleLowerCase().match(this.name.toLocaleLowerCase());
    });
  }else if(this.name!="")
  this.ngOnInit();
}





}


