import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

 /*
  id:number;
  constructor(private route:ActivatedRoute){
    this.route.params.subscribe(params => {this.id = +params['id'];});
    console.log("ID value is:" +this.id);
    alert(this.id);
  } */
  
  ngOnInit(): void {
  }


}
