export class Trains
{
    id:number;
    name:string;
    class : string;
    traveller : string;
    phone : number;
    aadhar : number;
    from : string;
    to : string;
    station : string;
}