import { TestBed } from '@angular/core/testing';

import { AuthserviceService } from './authservice.service';

describe('AuthserviceService', () => {
  let service: AuthserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it(`to get product() of service`, () => {
    expect(service.calculateProduct(20, 30)).toEqual(600);
  });
});
