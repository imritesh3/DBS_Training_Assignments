import { Component, ɵSWITCH_COMPILE_NGMODULE__POST_R3__ } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'TestApp';
  var = 'ritesh';

  res: number;
  mul(num1: number, num2: number) {
    if (num1 > 0) {
      this.res = num1 * num2;
      return this.res;
    } else return num2;
  }

  response: string;

  hitMe() {
    this.response = 'Hey! Welcome to Angular!';
    alert(this.response);
  }

  fun() {
    console.log('Testing to check code coverage');
  }

  dummyFun() {
    console.log('Testting code coverage');
  }

  evenOdd(num: number): string {
    if (num % 2 == 0) return 'even';
    else return 'odd';
  }

  factorialNum(num: number) {
    if (num == 0 || num == 1) return 1;
    else if (num < 0)
      return 'factorial can be calculated only for positive numbers';
    else return num * this.factorialNum(num - 1);
  }

  divideNum(num1: number, num2: number) {
    if (num2 == 0) return 0;
    else return num1 / num2;
  }

  name: string;
  age: number;
  constructor() {
    this.name = 'Ritesh';
    this.age = 22;
    alert('Name is:' + this.name);
    alert('Age is' + this.age);
  }
}
