import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'TestApp'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('TestApp');
  });

  /* it('should render title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.content span').textContent).toContain(
      'TestApp app is running!'
    );
  }); */

  it(`test`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.var).toEqual('ritesh');
  });

  it(`Testing Multiplication`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance.mul(2, 5);
    expect(app).toEqual(10);
  });

  it(`Should have title  Welcome to Angular as h1 element `, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;

    //checking the h1 element
    const title = fixture.debugElement.query(By.css('h1')).nativeElement;
    expect(title.innerHTML).toEqual('Welcome to Angular');
  });

  it(`Checking the button content as HIT ME and also clicking it`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    const button = fixture.debugElement.nativeElement.querySelector('#btn');
    button.click();
    expect(button.innerHTML).toBe('HIT ME');
    expect(app.response).toEqual('Hey! Welcome to Angular!');
  });

  it(`Even or Odd`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance.evenOdd(3);
    expect(app).toEqual('odd');
  });

  it(`Factorial of a number`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance.factorialNum(5);
    expect(app).toEqual(120);
  });

  it(`Division of two numbers`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance.divideNum(3, 2);
    expect(app).toEqual(1.5);
  });

  it(`Constructor proper data`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.name).toEqual('Ritesh');
  });

  it('Button click to set params in constuctor', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    const btn = fixture.debugElement.nativeElement.querySelector('#srh');
    btn.click();
    expect(app.name).toEqual('Ritesh');
    expect(app.age).toEqual(22);
  });
});
