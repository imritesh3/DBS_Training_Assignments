import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-new-cmp',
  templateUrl: './new-cmp.component.html',
  styleUrls: ['./new-cmp.component.css']
})
export class NewCmpComponent implements OnInit {

  @Input() Message :string;


  @Output() public myOutput = new EventEmitter();

  buttonClick():void{
    this.myOutput.emit("Hello Parent!!");
  }


  constructor() { }

  ngOnInit(): void {
  }

}
