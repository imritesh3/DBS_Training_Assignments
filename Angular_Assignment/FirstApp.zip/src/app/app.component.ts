import { Component } from '@angular/core';
import { MyserviceService } from './myservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FirstApp';

  constructor(private myservice: MyserviceService){}

    today = this.myservice.showDate();
    

  name:string = "Ritesh Yadav Keshaboina";

  OnButtonClicked($event)
  {
    console.log("Button clicked ",$event);
    alert("Button is clicked");
  }

  imageURL:string ="../assets/himalayas.jpg";


  months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"]


  h1color:string='red';
  changeColor()
  {
    this.h1color = '#00FF00';
  }


  pipe_data:string = "Hi! Welcome to Aatmnirbhar Bharat."


 
   Message:string = "Hey!You'll receive a message from parent";

    childToParent :string;

    MessageFromChild(e)
    {
      this.childToParent = e;
      alert("Message from child to parent is: "+this.childToParent);
    }

    




}


