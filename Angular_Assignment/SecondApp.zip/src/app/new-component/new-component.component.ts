import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-component',
  templateUrl: './new-component.component.html',
  styleUrls: ['./new-component.component.css']
})
export class NewComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  imageURL:string = "../assets/temple.jpg";

  num1:number = 20;
  num2:number =  3;
  sum = this.num1+this.num2;
  diff = this.num1-this.num2;
  prod = this.num1*this.num2;
  div = this.num1/this.num2;
  mod = this.num1%this.num2;

  firstName:string ="Ritesh Yadav";
  lastName:string = "Keshaboina";

  OnButtonClicked($event){
    console.log("Button clicked!!!",$event);
    alert("Hit me button is clicked");
  }

  clickMe($event)
  {
    alert("Fullname: " +(this.firstName+this.lastName));
  }


  basic:number = 1000;
  HRA:number = 200;
  DA:number = 500;
  deductions:number = 150;
  IT:number = 350;

  grossSalary:number = this.basic + this.HRA +this.DA;
  netSalary:number = this.grossSalary - (this.deductions+this.IT)

  totalSalary($event){

    alert("Total Gross Salary and Net salary of the employee is: "+this.grossSalary +" and"+this.netSalary);
  }


  userName:string ="";



  months = ["January","February","March","April","May","June","July","August","September","October","November","December"]


  names = ["Akriti","Ashish","Keshava","Maniteja","Niharika","Padmini","Rakesh","Ritesh","Sai Roja","Soumya","Ujjwal","Vineela"]



  h1color:string='red';
  changeColor()
  {
    this.h1color = '#00FF00';
  }


  data ="Sunrisers Hyderabad";
  money =1000;
  selectedCurrency: string = '';
  selectChangeHandler(event :any){
    this.selectedCurrency = event.target.value;
  }



 
  dateNow:Date = new Date();
  object:Object = {id: '1', name: 'Ritesh Yadav', email:'riteshyadav654@gmail.com'};


 n:number = 0.312;




}
