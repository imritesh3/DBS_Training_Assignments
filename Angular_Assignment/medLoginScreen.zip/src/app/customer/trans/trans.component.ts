import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { TransService } from 'src/app/services/trans.service';
import { Transactions } from 'src/app/transactions';

@Component({
  selector: 'app-trans',
  templateUrl: './trans.component.html',
  styleUrls: ['./trans.component.css'],
})
export class TransComponent implements OnInit {
  constructor(private tService: TransService, private lService: LoginService) {}

  t: any = [];
  c: Transactions[] = [];

  name: string = this.lService.user;

  ngOnInit(): void {
    this.t = this.tService.getTransaction();
    for (let i = 0; i < this.t.length; i++) {
      if (this.name == this.t[i].cust_name) {
        const x = new Transactions(
          this.t[i].transaction_id,
          this.t[i].date,
          this.t[i].cust_name,
          this.t[i].medicines,
          this.t[i].amount
        );
        this.c.push(x);
      }
    }
    console.log(this.c);
  }
}
