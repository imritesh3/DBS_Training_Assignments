import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';
import { TransService } from '../services/trans.service';
import { Transactions } from '../transactions';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
})
export class CustomerComponent implements OnInit {
  constructor(private lService: LoginService, private tService: TransService) {}

  ngOnInit(): void {}
  id: number;
  name: string;
  date: string;
  med: string;
  amt: string;
  flag: number = 0;

  purchaseStrepsils() {
    console.log(this.lService.user);
    this.id = 111;
    this.date = '19/10/2020 12:24:56 PM';
    this.name = this.lService.user;
    this.med = 'Strepsils';
    this.amt = '100';
    const x = new Transactions(
      this.id,
      this.date,
      this.name,
      this.med,
      this.amt
    );
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 1;
  }

  purchaseMasks() {
    console.log(this.lService.user);
    this.id = 112;
    this.date = '11/01/2019 12:24:56 PM';
    this.name = this.lService.user;
    this.med = 'Pack of 10 Masks';
    this.amt = '200';
    const x = new Transactions(
      this.id,
      this.date,
      this.name,
      this.med,
      this.amt
    );
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 2;
  }

  purchaseVolini() {
    console.log(this.lService.user);
    this.id = 113;
    this.date = '19/01/2019 12:24:56 PM';
    this.name = this.lService.user;
    this.med = 'Volini';
    this.amt = '170';
    const x = new Transactions(
      this.id,
      this.date,
      this.name,
      this.med,
      this.amt
    );
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 3;
  }

  purchaseDolo() {
    console.log(this.lService.user);
    this.id = 114;
    this.date = '10/01/2019 12:24:56 PM';
    this.name = this.lService.user;
    this.med = 'Dolo';
    this.amt = '250';
    const x = new Transactions(
      this.id,
      this.date,
      this.name,
      this.med,
      this.amt
    );
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 4;
  }

  purchaseParacetamol() {
    console.log(this.lService.user);
    this.id = 115;
    this.date = '11/01/2020 12:24:56 PM';
    this.name = this.lService.user;
    this.med = 'Paracetamol';
    this.amt = '125';
    const x = new Transactions(
      this.id,
      this.date,
      this.name,
      this.med,
      this.amt
    );
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 5;
  }

  purchaseVicks() {
    console.log(this.lService.user);
    this.id = 116;
    this.date = '11/01/2018 12:24:56 PM';
    this.name = this.lService.user;
    this.med = 'Vicks Vaporub';
    this.amt = '50';
    const x = new Transactions(
      this.id,
      this.date,
      this.name,
      this.med,
      this.amt
    );
    console.log(x);
    this.tService.addTransaction(x);
    this.flag = 6;
  }
}
