import { Component, ViewChild, OnInit, AfterViewInit } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { TransService } from '../services/trans.service';
import { Transactions } from '../transactions';

/*export interface MedicalTransaction {
  transaction_id: number;
  date: string;
  cust_name: string;
  medicines: string;
  amount: string;
}

let ELEMENT_DATA: MedicalTransaction[] = [
  {
    transaction_id: 101,
    date: '12/10/2019 12:45:56 PM',
    cust_name: 'Ritesh',
    medicines: 'Zincovit',
    amount: '100',
  },
  {
    transaction_id: 102,
    date: '14/10/2019 10:01:12 PM',
    cust_name: 'Gautam',
    medicines: 'Vit C',
    amount: '50',
  },
  {
    transaction_id: 103,
    date: '17/10/2019 10:45:45 AM',
    cust_name: 'Rajni',
    medicines: 'Strepsils',
    amount: '200',
  },
  {
    transaction_id: 104,
    date: '12/12/2019 02:23:56 PM',
    cust_name: 'Tarun',
    medicines: 'Crocin',
    amount: '250',
  },
  {
    transaction_id: 105,
    date: '12/12/2019 01:01:23 AM',
    cust_name: 'Dileep',
    medicines: 'Moov',
    amount: '110',
  },
  {
    transaction_id: 106,
    date: '23/06/2020 06:22:34 PM',
    cust_name: 'Rahul',
    medicines: 'Calapa',
    amount: '150',
  },
  {
    transaction_id: 107,
    date: '04/10/2018 03:45:56 PM',
    cust_name: 'Vikram',
    medicines: 'Clavin',
    amount: '300',
  },
  {
    transaction_id: 108,
    date: '30/09/2017 05:45:53 PM',
    cust_name: 'Sravan',
    medicines: 'Vicks',
    amount: '180',
  },
  {
    transaction_id: 109,
    date: '11/01/2019 12:24:56 PM',
    cust_name: 'Shanky',
    medicines: 'Dolo',
    amount: '700',
  },
  {
    transaction_id: 110,
    date: '01/01/2016 08:45:36 AM',
    cust_name: 'Akash',
    medicines: 'Paracetamol',
    amount: '200',
  },
];
 */
@Component({
  selector: 'app-medical',
  templateUrl: './medical.component.html',
  styleUrls: ['./medical.component.css'],
})
export class MedicalComponent implements AfterViewInit {
  constructor(private tService: TransService) {}

  displayedColumns: string[] = [
    'transaction_id',
    'date',
    'cust_name',
    'medicines',
    'amount',
  ];

  t: Transactions[] = this.tService.getTransaction();

  dataSource = new MatTableDataSource(this.t);

  @ViewChild(MatSort) sort: MatSort;

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  public doFilter = (value: string) => {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  };
}
