export class Transactions {
  transaction_id: number;
  date: string;
  cust_name: string;
  medicines: string;
  amount: string;
  constructor(
    transaction_id: number,
    date: string,
    cust_name: string,
    medicines: string,
    amount: string
  ) {
    this.transaction_id = transaction_id;
    this.date = date;
    this.cust_name = cust_name;
    this.medicines = medicines;
    this.amount = amount;
  }
}
