import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from '@angular/forms';
import { errorMonitor } from 'events';
import { Login } from '../login';
import { LoginService } from '../services/login.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css'],
})
export class CheckoutComponent implements OnInit {
  checkoutform: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private loginservice: LoginService
  ) {
    this.checkoutform = formBuilder.group({
      emailAddr: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  ngOnInit(): void {}

  /*cred: Login[] = [
    new Login(1, 'ritesh@gmail.com', 'ritesh123', 'admin'),
    new Login(2, 'gautam@gmail.com', 'gautam123', 'user'),
  ];

  ngOnInit(): void {}

  flag: boolean = false;
  postData() {
    for (let i = 0; i < this.cred.length; i++) {
      if (
        this.checkoutform.value.emailAddr == this.cred[i].username &&
        this.checkoutform.value.password == this.cred[i].password
      ) {
        this.flag = true;
        break;
      } else {
        this.flag = false;
      }
    }
    if (this.flag == true) alert('Valid credentials');
    else alert('Invalid credentials');
  }

  loginClicked() {
    this.router.navigate(['/medical']);
  }
  */

  user: Login[];
  username: string;
  password: string;
  index: number;

  postData() {
    const value = this.checkoutform.value;
    console.log('Form Details:' + value);
    this.username = this.checkoutform.value.emailAddr;
    console.log('Entered email id:' + this.username);
    this.password = this.checkoutform.value.password;
    console.log('Entered password is:' + this.password);
    this.index = this.loginservice.logUserService(this.username, this.password);
    console.log('index:' + this.index);
    if (this.index == -1) {
      alert('Invalid user');
    } else if (this.index == 0) {
      console.log('Admin');
      this.router.navigate(['/medical']);
    } else {
      console.log('Customer');
      this.router.navigate(['/customer']);
    }
  }
}
