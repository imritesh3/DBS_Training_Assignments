export class Login {
  id: number;
  username: string;
  password: string;
  type: string;
  fname: string;

  constructor(id, username, password, type, fname) {
    this.id = id;
    this.username = username;
    this.password = password;
    this.type = type;
    this.fname = fname;
  }
}
