import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckoutComponent } from './checkout/checkout.component';
import { CustomerComponent } from './customer/customer.component';
import { TransComponent } from './customer/trans/trans.component';
import { ForgotpassComponent } from './forgotpass/forgotpass.component';
import { HomeComponent } from './home/home.component';
import { MedicalComponent } from './medical/medical.component';
import { SigninComponent } from './signin/signin.component';

const routes: Routes = [
  { path: 'signin', component: SigninComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'forgotpass', component: ForgotpassComponent },
  { path: 'home', component: HomeComponent },
  { path: 'medical', component: MedicalComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'customer/transaction', component: TransComponent },
  { path: 'logout', redirectTo: 'checkout', pathMatch: 'full' },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
