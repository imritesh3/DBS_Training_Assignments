import { Injectable } from '@angular/core';
import { mUser } from 'src/assets/data/mock-user';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor() {}

  user: string;
  logUserService(email: string, password: string): number {
    let idx = -1;
    for (let i = 0; i < mUser.length; i++) {
      const em = mUser[i].username;
      const pass = mUser[i].password;
      if (em == email && pass == password) {
        idx = i;
        console.log('Index :' + idx);
      }
    }
    this.user = mUser[idx].fname;
    console.log(this.user);
    return idx;
  }
}
