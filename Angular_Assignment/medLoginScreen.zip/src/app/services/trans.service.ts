import { Injectable } from '@angular/core';
import { mTrans } from 'src/assets/data/mock-trans';
import { Transactions } from '../transactions';

@Injectable({
  providedIn: 'root',
})
export class TransService {
  constructor() {}

  getTransaction(): Transactions[] {
    return mTrans;
  }

  addTransaction(x: Transactions) {
    mTrans.push(x);
    console.log(mTrans);
  }
}
