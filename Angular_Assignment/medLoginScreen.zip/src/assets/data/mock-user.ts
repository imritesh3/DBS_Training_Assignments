import { Login } from 'src/app/login';

export const mUser: Login[] = [
  {
    id: 1,
    username: 'ritesh@gmail.com',
    password: 'ritesh@123',
    type: 'admin',
    fname: 'Ritesh',
  },
  {
    id: 2,
    username: 'gautam@gmail.com',
    password: 'gautam@123',
    type: 'user',
    fname: 'Gautam',
  },
  {
    id: 3,
    username: 'tarun@gmail.com',
    password: 'tarun@123',
    type: 'user',
    fname: 'Tarun',
  },
  {
    id: 4,
    username: 'dileep@gmail.com',
    password: 'dileep@123',
    type: 'user',
    fname: 'Dileep',
  },
];
