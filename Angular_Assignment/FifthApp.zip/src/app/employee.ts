export class Employee {
public empId: number;
public name: string;
public dept: string;
public desig: string;
public salary: number;
 
constructor(empId, name, dept, desig, salary){
this.empId = empId;
this.name = name;
this.dept = dept;
this.desig = desig;
this.salary = salary;
    }
}