import { Injectable } from '@angular/core';
import {Employee } from './employee'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 
  private employees: Employee[] =[
  new Employee(1,"Chakri","ITT","Analyst",50000),
  
     ];
  constructor() { }
  getEmployees(){
  return this.employees.slice();
    }
  getEmployee(index: number){
  return this.employees[index];
    }
  addEmployee(employee: Employee){
  this.employees.push(employee);
    }
  updateEmployee(index: number, updatedEmployee: Employee){
  this.employees[index] = updatedEmployee;
    }
  deleteEmployee(index: number){
  this.employees.splice(index,1);
    }
  }
  
  
  
  
  
