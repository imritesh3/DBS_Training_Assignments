import { Component } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from'./employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FifthApp';

  constructor(private employeeService:EmployeeService){}

  emp1: Employee = this.employeeService.getEmployee(0);
employees: Employee[] = this.employeeService.getEmployees();
eId: number = 2;
eName: string = "Ritesh";
eDept: string = "TECH";
eDesig: string = "Developer";
eSalary: number = 30000;
 
e1Id: number = this.employees[0].empId;
e1Name: string = this.employees[0].name;
e1Dept: string = this.employees[0].dept;
e1Desig: string = this.employees[0].desig;
e1Salary: number = this.employees[0].salary;
addEmployee() {
var i: number;
var flag: boolean = true;
for (i = 0; i < this.employees.length; i++) {
if (this.employees[i].empId === +this.eId) {
flag = false;
alert("EmpId " + this.eId + " is already present in database.");
      }
    }
if (flag == true) {
this.employeeService.addEmployee(new Employee(this.eId, this.eName, this.eDept, this.eDesig, this.eSalary));
this.employees = this.employeeService.getEmployees();
alert("New Employee is added");
    }
  }
onOptionsSelected(value: number) {
var i: number;
for (i = 0; i < this.employees.length; i++) {
if (this.employees[i].empId === +value) {
break;
      }
    }
this.e1Id = this.employees[i].empId;
this.e1Name = this.employees[i].name;
this.e1Dept = this.employees[i].dept;
this.e1Desig = this.employees[i].desig;
this.e1Salary = this.employees[i].salary;
  }
updateEmployee() {
var i: number;
for (i = 0; i < this.employees.length; i++) {
if (this.employees[i].empId === +this.e1Id) {
this.employeeService.updateEmployee(i, new Employee(this.e1Id, this.e1Name, this.e1Dept, this.e1Desig, this.e1Salary));
alert("Employee with EmpId: " + this.e1Id + " updated");
break;
      }
    }
this.employees = this.employeeService.getEmployees();
  }
deleteEmployee() {
var i: number;
for (i = 0; i < this.employees.length; i++) {
if (this.employees[i].empId === +this.e1Id) {
this.employeeService.deleteEmployee(i);
alert("Employee with EmpId: " + this.e1Id + " deleted");
break;
      }
    }
this.employees = this.employeeService.getEmployees();
this.e1Id = this.employees[0].empId;
this.e1Name = this.employees[0].name;
this.e1Dept = this.employees[0].dept;
this.e1Desig = this.employees[0].desig;
this.e1Salary = this.employees[0].salary;
 
  }
}
