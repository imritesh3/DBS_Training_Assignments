package demo;

public class Scope {
	public String message;

	public void getMessage() {
		System.out.println("Your message : "+message);
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
