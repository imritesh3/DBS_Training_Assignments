package assignment;

public class Train {
 public int train_no;
 public String name;
 public String train_name;
 public String arrival;
 public String destination;
 public String status;
 
 
 
 public int getTrain_no() {
	return train_no;
}
public void setTrain_no(int train_no) {
	this.train_no = train_no;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getTrain_name() {
	return train_name;
}
public void setTrain_name(String train_name) {
	this.train_name = train_name;
}
public String getArrival() {
	return arrival;
}
public void setArrival(String arrival) {
	this.arrival = arrival;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
