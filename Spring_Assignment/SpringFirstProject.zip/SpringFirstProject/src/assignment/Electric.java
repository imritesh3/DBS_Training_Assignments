package assignment;

public class Electric {
	
	public int meter_no;
	public int initial_reading;
	public int current_reading;
	public String color;
	public int getMeter_no() {
		return meter_no;
	}
	public void setMeter_no(int meter_no) {
		this.meter_no = meter_no;
	}
	public int getInitial_reading() {
		return initial_reading;
	}
	public void setInitial_reading(int initial_reading) {
		this.initial_reading = initial_reading;
	}
	public int getCurrent_reading() {
		return current_reading;
	}
	public void setCurrent_reading(int current_reading) {
		this.current_reading = current_reading;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	

}
